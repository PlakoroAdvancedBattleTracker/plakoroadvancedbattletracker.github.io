/* Original evolutions inherit their three Enekoro and prepare one extra die. */
const ADV_EXTRA_ENEKORO=new Set(['kadabra','charizard','venusaur','blastoise']);
function addsEvolutionEnekoro(load){return !!load&&loadoutEdition(load)==='1997'&&ADV_EXTRA_ENEKORO.has(legacyNameKey(load.pokemon))}
function validEvolutionDie(record){return !!record&&['1997','2026'].includes(record.kind)&&nativeDiceValid([record.dice,record.dice,record.dice],[record.kind,record.kind,record.kind])}
function freshEvolutionDie(){return {kind:'1997',fixedLocked:false,dice:[['normal'],['normal'],['normal'],['normal'],['normal','normal'],['normal','normal']],editionDice:{}}}
function evolutionDie(load){if(!addsEvolutionEnekoro(load))return null;if(!validEvolutionDie(load.evolutionDie))load.evolutionDie=freshEvolutionDie();return load.evolutionDie}
function currentEvolutionDie(f){if(!f?.loadouts||!f.loadoutIndex)return null;let extra=null;for(const load of f.loadouts.slice(1,f.loadoutIndex+1))if(addsEvolutionEnekoro(load))extra=evolutionDie(load);return extra}
const evolutionCleanPlayer=cleanPlayer;
cleanPlayer=function(p){const value=evolutionCleanPlayer(p);value.evolutionLoadouts.forEach((l,i)=>{const record=p?.evolutionLoadouts?.[i]?.evolutionDie;if(validEvolutionDie(record))l.evolutionDie=clone(record)});return value};
const evolutionFreshFighter=freshFighter;
freshFighter=function(p,...args){const f=evolutionFreshFighter(p,...args);f.loadouts.forEach((load,i)=>{if(i&&addsEvolutionEnekoro(load))load.evolutionDie=clone(evolutionDie(p.evolutionLoadouts[i-1]))});if(currentEvolutionDie(f))f.baseEnergyDice=4;return f};
const evolutionTransition=applyChronicleTransition;
applyChronicleTransition=function(f,...args){if(!evolutionTransition(f,...args))return false;if(currentEvolutionDie(f))f.baseEnergyDice=4;return true};
const evolutionEnergyDice=energyDiceFor;
energyDiceFor=function(f){if(currentEvolutionDie(f)&&!(battle.borrowedMove&&f===battle.fighters[battle.turnIndex]))return Math.max(0,4+(f.energyMod||0));return evolutionEnergyDice(f)};
const evolutionAttackDice=pdAttackDice;
pdAttackDice=function(){const f=battle.fighters[battle.borrowedMove?battle.targetIndex:battle.turnIndex],base=evolutionAttackDice(),extra=currentEvolutionDie(f);return extra?[...base.slice(0,3),extra.dice]:base};
const evolutionEnrich=enrichLoad;
enrichLoad=function(load,slot,index){load=evolutionEnrich(load,slot,index);if(index>=0){const build=players[slot].evolutionLoadouts[index],record=evolutionDie(build);load.diceNote=record?'Keep the original three Enekoro and add one. Total: 4 Enekoro.':'Uses the existing Enekoro. No additional die.';load.showDice=!!record;load.diceOffset=3;load.diceHeading='Additional Enekoro';if(record){load.dice=[record.dice];load.diceKinds=[record.kind];load.fixedLocked=[record.fixedLocked];load.custom=true}}return load};
function evolutionSetupRecord(slot,index){return index>=0?evolutionDie(nativeLoadout(slot,index)):null}
function saveEvolutionDie(){saveBuilds();render()}
const evolutionSaveDice=nativeSetupActions.dice;
nativeSetupActions.dice=function(slot,name,dice,index=-1){if(index<0)return evolutionSaveDice(slot,name,dice);const record=evolutionSetupRecord(slot,index);if(!record||dice.length!==1||!validEvolutionDie({...record,dice:dice[0]}))return false;if(record.kind==='1997'&&record.fixedLocked&&JSON.stringify(record.dice.slice(0,4))!==JSON.stringify(dice[0].slice(0,4)))return false;record.dice=clone(dice[0]);saveEvolutionDie();return true};
const evolutionSetKind=nativeSetupActions.kind;
nativeSetupActions.kind=function(slot,die,kind,index=-1){if(index<0)return evolutionSetKind(slot,die,kind);const record=evolutionSetupRecord(slot,index);if(!record||die!==0||!['1997','2026'].includes(kind)||record.kind==='1997'&&record.fixedLocked)return;record.editionDice||={};record.editionDice[record.kind]=clone(record.dice);record.dice=clone(record.editionDice[kind]||(kind==='1997'?freshEvolutionDie().dice:PD.defaults(nativeLoadout(slot,index).pokemon)[0]));record.kind=kind;record.fixedLocked=false;saveEvolutionDie()};
const evolutionAssembly=nativeSetupActions.assembly;
nativeSetupActions.assembly=function(slot,die,assembled,index=-1){if(index<0)return evolutionAssembly(slot,die,assembled);const record=evolutionSetupRecord(slot,index);if(!record||die!==0||record.kind!=='1997')return false;record.fixedLocked=!!assembled;saveEvolutionDie();return true};
const evolutionResetDice=nativeSetupActions.resetDice;
nativeSetupActions.resetDice=function(slot,name,index=-1){if(index<0)return evolutionResetDice(slot,name);const record=evolutionSetupRecord(slot,index);if(!record)return [];const fresh=record.kind==='1997'?freshEvolutionDie().dice:PD.defaults(name)[0];if(record.kind==='1997'&&record.fixedLocked)fresh.splice(0,4,...clone(record.dice.slice(0,4)));record.dice=clone(fresh);saveEvolutionDie();return [record.dice]};
const evolutionAssemble=nativeAssembleBattleDice;
nativeAssembleBattleDice=function(fighters){evolutionAssemble(fighters);for(const f of fighters)f.loadouts.forEach((load,i)=>{if(!i)return;const record=evolutionDie(load);if(record){record.fixedLocked=record.kind==='1997';const build=players[f.playerIndex]?.evolutionLoadouts[i-1];if(build)build.evolutionDie=clone(record)}});saveBuilds()};
