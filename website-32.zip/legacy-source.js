/* Typed public Drive cards shared with Pokédex, adapted to Advanced's engine. */
(function(root){
 const TYPES=['grass','fire','water','lightning','psychic','fighting','dark','steel','dragon','flying','normal'],FACING=['standing','handstand','back','down','left','right'];
 const clean=s=>{const text=String(s??'').replace(/[?？]/g,'').replace(/\s+/g,' ').trim();return text==='ミラクルビーム'?'Miracle Beam':text},name=s=>clean(s)==='Bulbasuar'?'Bulbasaur':clean(s);
 function fields(card){if(card.battle?.schema!==1||!card.battle.fields||typeof card.battle.fields!=='object')throw Error('This card update needs typed battle metadata. The included cards are kept.');return card.battle.fields}
 function move(card){
  if(!/^OGW\d+(?:-\d+)+$/.test(card.code||card.id||''))return null;
  const d=fields(card),effects=[0,1,2,3].map(i=>String(d['move_text_'+i]||'').trim()),energy=[];
  for(const [field,t]of Object.entries({grass:'grass',fire:'fire',water:'water',electric:'lightning',psychic:'psychic',fighting:'fighting',dark:'dark',steel:'steel',dragon:'dragon',flying:'flying',normal:'normal'})){const n=Number(d[field+'_energy']||0);if(!Number.isInteger(n)||n<0||n>99)throw Error('Invalid card energy');energy.push(...Array(n).fill(t))}
  const baseDamage=typeof d.damage==='string'?Number(d.damage.trim()||0)*10:0;
  if(!Number.isFinite(baseDamage)||!TYPES[d.type])throw Error('Invalid battle metadata');
  const m={code:card.code||card.id,name:clean(d.move_name),owner:name(d.mon_name),type:TYPES[d.type],image:card.image,source:'1997',chronicle:true,sourceUrl:card.sourceUrl,sourcePath:card.sourcePath,baseDamage,damage:baseDamage/10,energy,effect:'',effects,outcomes:[],special:effects.some(t=>/special move/i.test(t))};
  const required=/^(?:\{(?:st|hs|ba|do|s1|s2)\}\s*)+$/.test(effects[0]),map={st:'standing',hs:'handstand',ba:'back',do:'down',s1:'left',s2:'right'};
  if(required){m.requiredOrientations=[...effects[0].matchAll(/\{(st|hs|ba|do|s1|s2)\}/g)].map(x=>map[x[1]]);m.outcomes=[{orientations:m.requiredOrientations,text:effects[1]}];m.effect=effects.slice(2).filter(t=>t&&!/^Special Move:/i.test(t)).join(' ')}
  else{const plain=[effects[0]];for(let i=1;i<4;i++){if(!effects[i])continue;const orientations=FACING.filter((_,j)=>d['move_'+i+'_facing_'+j]);if(orientations.length)m.outcomes.push({orientations,text:effects[i]});else plain.push(effects[i])}m.effect=plain.filter(Boolean).join(' ')}
  const text=effects.join(' '),failure=/If this moves? fails, this pokemon takes (\d+) damage/i.exec(text);if(failure)m.failureDamage=+failure[1];
  if(/^(Evolve|Devolve)$/i.test(m.name)){m.action=m.name.toLowerCase();const match=/(?:evolves?(?: it)?|evovles|Devolve this Pokemon) into ([^.]+)/i.exec(text);if(!match)throw Error('Missing evolution target');m.targets=match[1].split(/,\s*its maximum/i)[0].split(/,\s*(?:or\s+)?|\s+or\s+/).map(name).filter(Boolean).sort();const hp=/maximum HP becomes (\d+)/i.exec(text);if(hp)m.maxHp=+hp[1];const dice=/(?:Roll|rolls?) (\d+) enekoro/i.exec(text);m.energyDice=dice?+dice[1]:m.maxHp===160?4:3}
  const hpGate=/can only be used if your \w+ has (\d+) HP or less/i.exec(text);if(hpGate)m.maxUserHp=+hpGate[1];const conditional=/If Evolve failed on your last turn, this pokemon evolves into ([^.]+)/i.exec(text);if(conditional)m.conditionalEvolution=name(conditional[1]);return m;
 }
 function convert(raw,modernNames){
  const feed=root.ChronicleOG.catalogue(raw);if(feed.complete===false)throw Error('Incomplete original card update');const pokemon={},pools={},seen=new Set();
  for(const card of [...feed.moves,...feed.pokemon.flatMap(p=>p.moves||[])]){const m=move(card);if(!m||seen.has(m.code))continue;seen.add(m.code);(pools[m.owner]||=[]).push(m)}
  for(const card of feed.pokemon){const code=card.code||card.id;if(!/^OGC\d+(?:-\d+)+$/.test(code))continue;const d=fields(card),species=name(d.mon_name),choice=modernNames.includes(species)?species+' (1997)':species;let hp=Number(String(d.hp).trim());if(hp<30)hp*=10;if(!Number.isFinite(hp)||hp<=0||!TYPES[d.type])throw Error('Invalid original Pokémon card');pokemon[choice]={pokemon:{name:choice,species,code,hp,type:TYPES[d.type],weakness:'',image:card.image,source:'1997',sourceUrl:card.sourceUrl},moves:pools[species]||[]};}
  if(!Object.keys(pokemon).length||!seen.size)throw Error('Empty original card update');
  return {order:Object.keys(pokemon),pokemon,movePools:pools,driveFolder:feed.source,checked:feed.checkedAt||feed.snapshotDate,revision:feed.revision,note:'Original OG cards only; automatic Drive checks.'};
 }
 root.AdvancedLegacySource={move,convert};
})(window);
