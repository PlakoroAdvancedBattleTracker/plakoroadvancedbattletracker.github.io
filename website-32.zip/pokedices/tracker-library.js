/* Thirty Advanced-only recipe slots; live battles are saved separately. */
const ADV_SAVED_KEY='plakoro-advanced-loadout-slots-v1';
let advancedSaved=Array(30).fill(null),advancedSavedPick={};
try{const old=JSON.parse(localStorage.getItem(ADV_SAVED_KEY)||'null');if(Array.isArray(old?.slots))advancedSaved=Array.from({length:30},(_,i)=>old.slots[i]||null)}catch{}
function saveRecipeSlots(){localStorage.setItem(ADV_SAVED_KEY,JSON.stringify({version:1,slots:advancedSaved}))}
function savedPick(key){return advancedSavedPick[key]||0}
function savedControls(key,kind,canSave){const index=savedPick(key);return {index,options:advancedSaved.map((s,i)=>({value:i,label:(i+1)+' · '+(s?(s.kind==='party'?'League party · ':pokemonLabel(s.build?.pokemon)+' · ')+(s.kind==='party'?s.format==='leagueDouble'?'Doubles':'Singles':s.legacy?'Legacy':'Modern'):'Empty')})),canSave,canLoad:advancedSaved[index]?.kind===kind}}
function chooseSaved(key,value){const index=Number(value);if(!Number.isInteger(index)||index<0||index>=30)return;advancedSavedPick[key]=index;render()}
function archiveBuild(slot){const build=cleanPlayer(players[slot]);const f=battle?.format===battleFormat?battle.fighters.find(f=>f.playerIndex===slot&&f.loadouts?.[0]?.pokemon===build.pokemon):null;if(f){build.savedHp=f.hp;build.savedForm=f.loadoutIndex||0}return build}
function savePokemonRecipe(slot){if(!players[slot]?.pokemon)return;advancedSaved[savedPick('mon/'+slot)]={kind:'pokemon',build:archiveBuild(slot),dice:clone(slotDiceRecord(slot)),chronicle:chronicleMode,legacy:legacyMode};saveRecipeSlots();render()}
function loadPokemonRecipe(slot){const saved=advancedSaved[savedPick('mon/'+slot)];if(saved?.kind!=='pokemon')return;chronicleMode=!!saved.chronicle;legacyMode=!!saved.legacy;players[slot]=cleanPlayer(saved.build);syncEvolutionLoadouts(players[slot]);const dice=nativeSlotDiceState();dice[battleFormat+'/'+slot]=clone(saved.dice||{});localStorage.setItem(nativeSlotDiceKey,JSON.stringify(dice));saveAdvancedRules();render()}
function savePartyRecipe(){const trainer=leagueSetup.trainer,ids=Array.from({length:6},(_,i)=>trainer*6+i);if(!ids.every(i=>players[i]?.pokemon))return;advancedSaved[savedPick('party/'+trainer)]={kind:'party',format:battleFormat,builds:ids.map(archiveBuild),dice:ids.map(i=>clone(slotDiceRecord(i))),chronicle:chronicleMode,legacy:legacyMode};saveRecipeSlots();render()}
function loadPartyRecipe(){const trainer=leagueSetup.trainer,saved=advancedSaved[savedPick('party/'+trainer)];if(saved?.kind!=='party')return;chronicleMode=!!saved.chronicle;legacyMode=!!saved.legacy;const dice=nativeSlotDiceState();for(let i=0;i<6;i++){const slot=trainer*6+i;players[slot]=cleanPlayer(saved.builds[i]);syncEvolutionLoadouts(players[slot]);dice[battleFormat+'/'+slot]=clone(saved.dice?.[i]||{})}localStorage.setItem(nativeSlotDiceKey,JSON.stringify(dice));leagueSetup.selections[trainer]=[];leagueSetup.phase='party';saveAdvancedRules();render()}
const savedEnrich=enrichLoad;
enrichLoad=function(load,slot,index){load=savedEnrich(load,slot,index);if(index<0)load.saved=savedControls('mon/'+slot,'pokemon',!!players[slot]?.pokemon);return load};
Object.assign(nativeSetupActions,{savedSelect:(slot,value)=>chooseSaved('mon/'+slot,value),savedSave:savePokemonRecipe,savedLoad:loadPokemonRecipe});
const savedLeagueProps=leagueSetupProps;
leagueSetupProps=function(){const state=savedLeagueProps();if(state.phase==='party')state.savedParty=savedControls('party/'+state.trainer,'party',players.slice(state.trainer*6,state.trainer*6+6).every(p=>p.pokemon));return state};
Object.assign(nativeSetupActions,{partySavedSelect:value=>chooseSaved('party/'+leagueSetup.trainer,value),partySavedSave:savePartyRecipe,partySavedLoad:loadPartyRecipe});
