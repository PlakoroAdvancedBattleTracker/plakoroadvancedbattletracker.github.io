/* Apply original-card updates between battles, retaining Advanced identities. */
PD.pokemonLabel=pokemonLabel;
function migrateAdvancedChoice(p){
 if(!p)return p;const byCode=Object.keys(CHRONICLE_DB.pokemon).find(n=>CHRONICLE_DB.pokemon[n].pokemon.code===String(p.pokemon||'').replace(/^RE(?=C)/,'OG'));
 if(byCode)p.pokemon=byCode;else if(p.cardEdition==='1997'&&CHRONICLE_DB.pokemon[p.pokemon+' (1997)'])p.pokemon+=' (1997)';
 if(p.pokemon)p.cardEdition=DATA.order.includes(p.pokemon)?'2026':'1997';p.moves=(p.moves||[]).map(hydrateMove).filter(m=>m&&!/^RE/.test(m.code||''));
 if(p.lastMove)p.lastMove=cleanMoveName(p.lastMove);if(p.forcedMove)p.forcedMove=cleanMoveName(p.forcedMove);if(p.bannedMoves)p.bannedMoves=p.bannedMoves.map(cleanMoveName);
 for(const l of p.evolutionLoadouts||[])migrateAdvancedChoice(l);return p;
}
function migrateAdvancedSaves(){
 players.forEach(migrateAdvancedChoice);for(const setup of Object.values(formatSetups))setup.players?.forEach(migrateAdvancedChoice);
 const visit=b=>{if(!b)return;for(const f of b.fighters||[]){migrateAdvancedChoice(f);f.loadouts?.forEach(migrateAdvancedChoice)}visit(b.snapshot);b.leagueInitial?.forEach(f=>{migrateAdvancedChoice(f);f.loadouts?.forEach(migrateAdvancedChoice)})};visit(battle);
 for(const slot of advancedSaved)if(slot){if(slot.build)migrateAdvancedChoice(slot.build);slot.builds?.forEach(migrateAdvancedChoice)}saveRecipeSlots();saveBuilds();saveBattle();
}
function installAdvancedChronicle(){
 const next=AdvancedLegacySource.convert(window.CHRONICLE_DATA,DATA.order),modern=ALL_MOVES.filter(m=>!m.chronicle),oldNames=Object.keys(CHRONICLE_DB.pokemon);
 for(const name of oldNames)if(!DATA.order.includes(name))delete DATA.pokemon[name];
 Object.assign(CHRONICLE_DB,next);
 for(const [name,b]of Object.entries(next.pokemon)){DATA.pokemon[name]=b;POKEMON_META[name]={hp:b.pokemon.hp,type:b.pokemon.type,weakness:''};LEGACY_POKEMON_META[name]=POKEMON_META[name]}
 ALL_MOVES.splice(0,ALL_MOVES.length,...modern,...Object.values(next.movePools).flat());migrateAdvancedSaves();render();
}
window.AdvancedChronicleCanApply=()=>!battle||battle.phase==='winner';
window.addEventListener('chronicle-updated',installAdvancedChronicle);
migrateAdvancedSaves();
const updatesRender=render;
render=function(){ChronicleSync.maybeApply();updatesRender()};
const updatesStatus=renderUpdateStatus;
renderUpdateStatus=function(){return updatesStatus()+`<section class="update-status"><h3>Original Legacy cards · OG only</h3><p id="chronicle-status" role="status">${esc(ChronicleSync.status)}</p><p>${Object.keys(CHRONICLE_DB.pokemon).length} original Pokémon · ${Object.values(CHRONICLE_DB.movePools).flat().length} Legacy moves · Checks on opening, returning and every 30 minutes while open. Card downloads resume after closing.</p></section>`};
stage.addEventListener('click',e=>{const b=e.target.closest('[data-action]');if(b?.dataset.action==='check-updates')ChronicleSync.check(true)});
const physicalAttack=renderAttack;
renderAttack=function(){const html=physicalAttack(),f=battle.fighters[battle.turnIndex];if(f.diceOptional&&battle.diceSession?.phase==='roll')return html.replace(/<button[^>]*data-action="pd-roll"[^>]*>[\s\S]*?<\/button>/,'').replace(/<section class="tray"[\s\S]*?<\/section>/,'<p>Use your physical Energy Dice. Count both symbols on double chips and keep earlier results when adding bonus rolls.</p>');return html};
let modernLastOpen=0;
function advancedOpened(){if(document.hidden||Date.now()-modernLastOpen<1000)return;modernLastOpen=Date.now();cardUpdater?.check();window.dispatchEvent(new Event('plakoro-app-open'))}
window.addEventListener('focus',advancedOpened);window.addEventListener('pageshow',e=>{if(e.persisted)advancedOpened()});document.addEventListener('visibilitychange',()=>{if(!document.hidden)advancedOpened()});
if(parent!==window){parent.addEventListener('focus',advancedOpened);parent.document.addEventListener('visibilitychange',()=>{if(!parent.document.hidden)advancedOpened();else window.dispatchEvent(new Event('plakoro-app-close'))});}
ChronicleSync.start();render();
